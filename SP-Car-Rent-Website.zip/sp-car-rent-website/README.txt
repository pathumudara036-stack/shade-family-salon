SP CAR RENT (PVT) LTD WEBSITE

Files:
- index.html
- style.css
- script.js
- assets/ (uploaded vehicle photos)

HOW TO USE:
1. Keep the folder structure unchanged.
2. Double-click index.html to preview it.
3. Upload the whole folder to your hosting/GitHub Pages.
4. Replace/add vehicle photos inside assets if needed.

The website includes:
- Premium dark responsive design
- Vehicle categories and filters
- WhatsApp booking enquiry form
- Call, email, TikTok and Facebook links
- Tourist-focused Sri Lanka rental section
- Mobile menu
- Floating WhatsApp button

Important:
The site does not display rental prices because no verified prices were supplied. Contact SP Car Rent for current rates and availability.
